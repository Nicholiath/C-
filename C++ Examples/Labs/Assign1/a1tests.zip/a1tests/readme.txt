The sample output were generated in a Linux system using the following
commands:

./csort 1 < _data > _data_1
./csort -1 < _data > _data_-1
./csort 11 < _data2 > _data2_11
./csort -11 < _data2 > _data2_-11

./csort 1s < _data > _data_1s
./csort -1s < _data > _data_-1s
./csort 11s < _data2 > _data2_11s
./csort -11s < _data2 > _data2_-11s
./csort -1s < _data3 > _data3_-1s

./csort 1,-2,3 < DATA > DATA_1,-2,3
./csort 1,2,3 < DATA > DATA_1,2,3
./csort 3,2,1 < DATA > DATA_3,2,1

./csort 1,-2,3 < DATA2 > DATA2_1,-2,3
./csort 1,2,3 < DATA2 > DATA2_1,2,3
./csort 3,2,1 < DATA2 > DATA2_3,2,1

./csort 1s,-2s,3s < DATA > DATA_1s,-2s,3s
./csort 1s,2s,3s < DATA > DATA_1s,2s,3s
./csort 3s,2s,1s < DATA > DATA_3s,2s,1s
./csort 1s,-2s,3s < DATA3 > DATA3_1s,-2s,3s
./csort 1s,2s,3s < DATA3 > DATA3_1s,2s,3s

./csort 3,-1s,5 < DATA4 > DATA4_3,-1s, -l
./csort 3,-1s,5s < DATA4 > DATA4_3,-1s,5s
./csort 1s,-3,-5 < DATA4 > DATA4_1s,-3,-5
./csort 1s,-3,-5s < DATA4 > DATA4_1s,-3,-5s

./csort 1,2,3,4,5,6 < _data4 > _data4_out
./csort 1,2,3,4,5,6,7,8,9,10 < _data5 > _data5_out
